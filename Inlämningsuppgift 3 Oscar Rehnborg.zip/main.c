#include "header.h"



int main(void)
{
    setup();
	
	while (1)
	if (led_enabled)
	{
		leds_blink();
	}
	else
	{
		LEDS_OFF;
	}
return 0;
}