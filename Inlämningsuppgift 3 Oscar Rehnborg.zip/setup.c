#include "header.h"
//statiska funktioner som bara syns i denna fil
static inline void init_ports(void);
static inline void init_interrupts(void);

//setup initierar portar och avbrottsrutiner
void setup()
{
	init_ports();
	init_interrupts();
	return;
}


static inline void init_ports(void)
{
	DDRB = (1 << LED1) | (1 << LED2) | (1 << LED3);      // pin 8-10 s�tts p� utport
	PORTB = (1 << BUTTON);                               // pin 13 s�tts p� inport
	return;
}

static inline void init_interrupts(void)
{
	asm("SEI");                    // K�r avbrott globalt
	PCICR = (1 << PCIE0);          // K�r avbrott p� PORTB
	PCMSK0 = (1 << BUTTON);        // Avbrott sl�s p� f�r knapp
	return;
}