#include "header.h"

//Blinkfunktionen som blinkar leds var 100 millisekund
void leds_blink()
{
	LEDS_OFF;
	LED1_ON;
	delay_ms(100);

	LED1_OFF;
	LED2_ON;
	delay_ms(100);

	LED2_OFF;
	LED3_ON;
	delay_ms(100);
	return;
}

void delay_ms(const volatile uint16_t delay_time_ms)
{
	for (uint16_t i = 0; i < delay_time_ms; ++i)
	{
		_delay_ms(1);
	}

	return;
}