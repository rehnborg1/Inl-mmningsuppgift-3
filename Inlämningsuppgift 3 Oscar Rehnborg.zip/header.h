// header.h inneh�ller inkluderingsbibliotek, funktioner, enumerationer och definitioner

#ifndef HEADER_H_
#define HEADER_H_

#define F_CPU 16000000UL // klockfrekvens 16 MHz.
// Inkluderingsbibliotek
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

//Knappmakro
#define BUTTON 5 // knapp ansluten till pin 13.
#define BUTTON_IS_PRESSED ((PINB & (BUTTON)) // Nedtryckning av knappp p� pin 13.

//Ledmakro
#define LED1 0 // Lysdiod 1 ansluten till pin 8 / PORTB0.
#define LED2 1 // Lysdiod 2 ansluten till pin 9 / PORTB1.
#define LED3 2 // Lysdiod 3 ansluten till pin 10 / PORTB2. 

#define LED1_ON PORTB |= (1 << LED1) // T�nder lysdiod 1.
#define LED2_ON PORTB |= (1 << LED2) // T�nder lysdiod 2. 
#define LED3_ON PORTB |= (1 << LED3) // T�nder lysdiod 3. 

#define LED1_OFF PORTB &= ~(1 << LED1) // Sl�cker lysdiod 1.
#define LED2_OFF PORTB &= ~(1 << LED2) // Sl�cker lysdiod 2.
#define LED3_OFF PORTB &= ~(1 << LED3) // Sl�cker lysdiod 3.

#define LEDS_ON PORTB |= (1 << LED1) | (1 << LED2) | (1 << LED3)     // T�nder lysdioderna.
#define LEDS_OFF PORTB &= ~((1 << LED1) | (1 << LED2) | (1 << LED3)) // Sl�cker lysdioderna.

// Enumeration
typedef enum { false = 0, true = 1 } bool;
bool led_enabled;

//funktioner
/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt aktiverar PCI-avbrott p�
*        tryckknappens pin.
********************************************************************************/
void setup(void); 

// blinkfunktion f�r lysdioderna.
void leds_blink();

// Delayfunktion som styr blinkhastigheten i millisekunder.
void delay_ms(const volatile uint16_t delay_time_ms);
#endif /* HEADER_H_ */